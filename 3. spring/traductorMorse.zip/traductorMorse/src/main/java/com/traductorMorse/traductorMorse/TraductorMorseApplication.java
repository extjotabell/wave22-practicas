package com.traductorMorse.traductorMorse;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TraductorMorseApplication {

	public static void main(String[] args) {
		SpringApplication.run(TraductorMorseApplication.class, args);
	}

}
