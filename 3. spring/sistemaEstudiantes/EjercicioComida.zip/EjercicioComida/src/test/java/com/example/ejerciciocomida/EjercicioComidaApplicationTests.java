package com.example.ejerciciocomida;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjercicioComidaApplicationTests {

    @Test
    void contextLoads() {
    }

}
