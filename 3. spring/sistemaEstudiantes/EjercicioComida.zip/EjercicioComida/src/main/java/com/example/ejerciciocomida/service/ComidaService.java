package com.example.ejerciciocomida.service;

import com.example.ejerciciocomida.repository.IComidaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ComidaService implements IComidaService{

    @Autowired
    IComidaRepository repository;

}
