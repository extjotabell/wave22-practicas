package com.example.ejerciciocomida.repository;

import com.example.ejerciciocomida.entity.Food;

import java.util.List;

public interface IComidaRepository {

    List<Food> getIngredientes();

}
