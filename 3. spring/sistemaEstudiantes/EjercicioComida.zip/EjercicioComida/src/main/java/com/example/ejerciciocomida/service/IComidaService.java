package com.example.ejerciciocomida.service;

public interface IComidaService {
}
