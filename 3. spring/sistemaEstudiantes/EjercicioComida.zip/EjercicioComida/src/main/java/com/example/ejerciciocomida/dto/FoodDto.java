package com.example.ejerciciocomida.dto;

import com.example.ejerciciocomida.entity.Food;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class FoodDto {
    private List<Food> ingredientes;
    // private Food ingredienteMayorCalorias;
    private Integer calorias;
    private Integer gramos;
}
