package com.calcEdades.edad;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EdadApplicationTests {

	@Test
	void contextLoads() {
	}

}
