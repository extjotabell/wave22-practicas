package com.calcEdades.edad;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EdadApplication {

	public static void main(String[] args) {
		SpringApplication.run(EdadApplication.class, args);
	}

}
