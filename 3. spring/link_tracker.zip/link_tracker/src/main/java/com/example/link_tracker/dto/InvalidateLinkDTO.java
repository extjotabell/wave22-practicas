package com.example.link_tracker.dto;

public class InvalidateLinkDTO {
    Integer linkId;
}
