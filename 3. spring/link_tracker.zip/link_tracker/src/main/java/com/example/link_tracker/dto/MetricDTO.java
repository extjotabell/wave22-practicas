package com.example.link_tracker.dto;


public class MetricDTO {
    private Integer linkId;
    private  Integer redirectCount;
}
