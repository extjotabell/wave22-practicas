package com.starwars.characters;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CharactersApplicationTests {

	@Test
	void contextLoads() {
	}

}
