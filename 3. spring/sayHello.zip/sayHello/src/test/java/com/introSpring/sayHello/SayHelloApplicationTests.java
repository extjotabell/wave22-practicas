package com.introSpring.sayHello;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SayHelloApplicationTests {

	@Test
	void contextLoads() {
	}

}
