package Spring.EjercicioLinkTracker.Exceptions;

public class InvalidFormatException extends RuntimeException{
    public InvalidFormatException(String message)
    {
        super(message);
    }
}
