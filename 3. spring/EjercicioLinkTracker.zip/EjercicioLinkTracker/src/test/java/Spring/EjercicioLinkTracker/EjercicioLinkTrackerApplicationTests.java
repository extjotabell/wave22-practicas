package Spring.EjercicioLinkTracker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjercicioLinkTrackerApplicationTests {

	@Test
	void contextLoads() {
	}

}
