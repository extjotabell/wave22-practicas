package com.bootcamp.elastic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ElasticApplicationTests {

	@Test
	void contextLoads() {
	}

}
