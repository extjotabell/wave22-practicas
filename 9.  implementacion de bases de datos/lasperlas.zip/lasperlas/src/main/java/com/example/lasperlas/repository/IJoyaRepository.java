package com.example.lasperlas.repository;

import com.example.lasperlas.model.Joya;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IJoyaRepository extends JpaRepository<Joya, Long> {

}
