package com.example.configdbs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConfigdbsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConfigdbsApplication.class, args);
	}

}
