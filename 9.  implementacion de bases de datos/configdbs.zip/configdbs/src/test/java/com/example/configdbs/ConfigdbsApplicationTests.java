package com.example.configdbs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConfigdbsApplicationTests {

	@Test
	void contextLoads() {
	}

}
