package com.example.showroom;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShowroomApplicationTests {

    @Test
    void contextLoads() {
    }

}
