INSERT INTO `ropa` ( `nombre`, `tipo`, `marca`, `color`, `talle`, `cantidad`, `precio_venta`)
VALUES
    ('Camiseta', 'Camiseta', 'Nike', 'Negro', 'M', 10, 19.99),
    ('Jeans', 'Pantalón', 'Levis', 'Azul', 'L', 5, 49.99),
    ('Sudadera', 'Sudadera', 'Adidas', 'Gris', 'XL', 7, 29.99),
    ('Vestido', 'Vestido', 'Zara', 'Rojo', 'S', 12, 39.99),
    ('Zapatos deportivos', 'Zapatos', 'Puma', 'Blanco', '42', 8, 59.99),
	('Chaqueta de cuero', 'Chaqueta', 'Harley-Davidson', 'Negro', 'M', 3, 199.99),
    ('Polo', 'Camiseta', 'Ralph Lauren', 'Blanco', 'L', 15, 79.99),
    ('Pantalón corto', 'Pantalón', 'Under Armour', 'Azul', 'S', 20, 29.99),
    ('Vestido de noche', 'Vestido', 'Dolce & Gabbana', 'Negro', 'L', 4, 499.99),
    ('Zapatos de tacón', 'Zapatos', 'Jimmy Choo', 'Plateado', '37', 6, 399.99);