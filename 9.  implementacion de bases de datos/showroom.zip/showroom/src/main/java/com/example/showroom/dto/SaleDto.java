package com.example.showroom.dto;

public class SaleDto {
}
