package com.example.empresaseguros.service;

import com.example.empresaseguros.dto.SiniestroDTO;

public interface ISiniestroService {

    Integer create(SiniestroDTO siniestro);

}
