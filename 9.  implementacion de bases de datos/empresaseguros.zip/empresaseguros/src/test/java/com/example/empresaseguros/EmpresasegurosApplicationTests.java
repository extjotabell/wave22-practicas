package com.example.empresaseguros;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmpresasegurosApplicationTests {

	@Test
	void contextLoads() {
	}

}
