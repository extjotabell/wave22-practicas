package com.example.joyeria_las_perlas;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JoyeriaLasPerlasApplicationTests {

    @Test
    void contextLoads() {
    }

}
