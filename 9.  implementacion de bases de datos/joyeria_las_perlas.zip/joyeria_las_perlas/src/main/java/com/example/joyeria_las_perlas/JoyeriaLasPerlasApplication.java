package com.example.joyeria_las_perlas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JoyeriaLasPerlasApplication {

    public static void main(String[] args) {
        SpringApplication.run(JoyeriaLasPerlasApplication.class, args);
    }

}
