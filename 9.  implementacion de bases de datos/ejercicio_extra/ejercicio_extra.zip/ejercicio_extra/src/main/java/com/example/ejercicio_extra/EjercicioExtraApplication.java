package com.example.ejercicio_extra;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EjercicioExtraApplication {

    public static void main(String[] args) {
        SpringApplication.run(EjercicioExtraApplication.class, args);
    }

}
