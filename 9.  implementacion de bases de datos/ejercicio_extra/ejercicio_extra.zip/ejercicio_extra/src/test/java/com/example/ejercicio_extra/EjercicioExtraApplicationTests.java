package com.example.ejercicio_extra;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjercicioExtraApplicationTests {

    @Test
    void contextLoads() {
    }

}
