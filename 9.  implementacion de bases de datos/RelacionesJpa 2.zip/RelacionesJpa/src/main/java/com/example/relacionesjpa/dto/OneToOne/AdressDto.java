package com.example.relacionesjpa.dto.OneToOne;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AdressDto {
    private String city;
}
