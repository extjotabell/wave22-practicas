package main;

public class Participante {

    private int num_participante;
    private int dni;
    private String nombre;
    private String apellido;
    private int edad;
    private int celular;
    private int num_emergencia;
    private String grupo_sanguineo;

    public Participante(int num_participante, int dni, String nombre, String apellido, int edad, int celular, int num_emergencia, String grupo_sanguineo) {
        this.num_participante = num_participante;
        this.dni = dni;
        this.nombre = nombre;
        this.apellido = apellido;
        this.edad = edad;
        this.celular = celular;
        this.num_emergencia = num_emergencia;
        this.grupo_sanguineo = grupo_sanguineo;
    }

    public int getNum_participante() {
        return num_participante;
    }

    public void setNum_participante(int num_participante) {
        this.num_participante = num_participante;
    }

    public int getDni() {
        return dni;
    }

    public void setDni(int dni) {
        this.dni = dni;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public int getCelular() {
        return celular;
    }

    public void setCelular(int celular) {
        this.celular = celular;
    }

    public int getNum_emergencia() {
        return num_emergencia;
    }

    public void setNum_emergencia(int num_emergencia) {
        this.num_emergencia = num_emergencia;
    }

    public String getGrupo_sanguineo() {
        return grupo_sanguineo;
    }

    public void setGrupo_sanguineo(String grupo_sanguineo) {
        this.grupo_sanguineo = grupo_sanguineo;
    }
}
