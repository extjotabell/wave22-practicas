package main;

import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String []args) {
        Categoria c1 = new Categoria(1, "Circuito Chico", "2km selva y arroyos");
        Categoria c2 = new Categoria(2, "Circuito Mediano", "5km por selva, arroyos y barro");
        Categoria c3 = new Categoria(3, "Circuito Avanzado", "10km por selva, arroyos,barro y escalada en piedra");

        List<Inscripcion> listaInsc = new ArrayList<>();

        Participante p1 = new Participante(1, 1, "Juan",
                                    "Perez", 21, 1,
                            1, "0-");

        Participante p2 = new Participante(2, 2, "Nestor",
                "Ortigoza", 15, 2,
                2, "0-");

        Participante p3 = new Participante(3, 13,"Leandro",
                "Romagnoli", 35, 3,
                3, "0-");

        Participante p4 = new Participante(4, 4, "Sebastian",
                "Torrico", 30, 4,
                4, "0-");

        listaInsc.add(inscribirCat1(p1,c1));
        listaInsc.add(inscribirCat2(p2,c2));
        listaInsc.add(inscribirCat3(p3,c3));
        listaInsc.add(inscribirCat1(p4,c1));

        for (Inscripcion ins: listaInsc) {
            System.out.println(ins.getNum_descripcion()+" "+
                    ins.getCategoria().getNombre()+" "+
                    ins.getParticipante().getNombre()+" "+
                    ins.getMonto());
        }

        mostrarPorCategoria(listaInsc);
        mostrarTotalPorCategoria(listaInsc);
        mostrarTotal(listaInsc);


    }

    private static void mostrarTotal(List<Inscripcion> listaInsc) {
        int total = 0;
        for (Inscripcion ins: listaInsc) {
            total += ins.getMonto();
        }
        System.out.println("-------MONTO TOTAL DE LAS INSCRIPCIONES----------");
        System.out.println("El monto total de todas las inscripciones es: "+total);
        System.out.println();
    }

    private static void mostrarTotalPorCategoria(List<Inscripcion> listaInsc) {
        int montoC1 = 0;
        int montoC2 = 0;
        int montoC3 = 0;
        for (Inscripcion ins: listaInsc) {
            if(ins.getCategoria().getId() == 1){
                montoC1 += ins.getMonto();
            } else if (ins.getCategoria().getId() == 2){
                montoC2 += ins.getMonto();
            }
            else {
                montoC3 += ins.getMonto();
            }
        }
        System.out.println("---------------------MONTO POR CATEGORIA-------------------------------");
        System.out.println("El monto total de Inscripciones para la categoria 1 es: "+montoC1);
        System.out.println("El monto total de Inscripciones para la categoria 2 es: "+montoC2);
        System.out.println("El monto total de Inscripciones para la categoria 3 es: "+montoC3);
        System.out.println();
    }

    private static void mostrarPorCategoria(List<Inscripcion> listaInsc) {
        System.out.println("---------LISTADO DE INSCRIPTOS-------------");

        System.out.println("Inscriptos en la categoria 1:");
        for (Inscripcion ins: listaInsc) {
            if(ins.getCategoria().getId() == 1){
                System.out.println("Num_insc: "+ins.getNum_descripcion()+" Nombre: "+ins.getParticipante().getNombre());
           }
       }
        System.out.println();
        System.out.println("Inscriptos en la categoria 2:");
        for (Inscripcion ins: listaInsc) {
            if(ins.getCategoria().getId() == 2){
                System.out.println("Num_insc: "+ins.getNum_descripcion()+" Nombre: "+ins.getParticipante().getNombre());
            }
        }
        System.out.println();
        System.out.println("Inscriptos en la categoria 3:");
        for (Inscripcion ins: listaInsc) {
            if(ins.getCategoria().getId() == 3){
                System.out.println("Num_insc: "+ins.getNum_descripcion()+" Nombre: "+ins.getParticipante().getNombre());
            }
        }
    }

    public static Inscripcion inscribirCat1(Participante p, Categoria c1){
            int monto = 1300;
            if(p.getEdad() >= 18){
                monto = 1500;
            }
            return new Inscripcion(1,c1,p,monto);

    }
    public static Inscripcion inscribirCat2(Participante p, Categoria c2){
        int monto = 2000;
        if(p.getEdad() >= 18){
            monto = 2300;
        }
        return new Inscripcion(1,c2,p,monto);

    }
    public static Inscripcion inscribirCat3(Participante p, Categoria c3){
        int monto = 2800;
        return new Inscripcion(1,c3,p,monto);

    }

}
