package main;

public class Inscripcion {

    private int num_descripcion;
    private Categoria categoria;
    private Participante participante;
    private int monto;

    public Inscripcion(int num_descripcion, Categoria categoria, Participante participante, int monto) {
        this.num_descripcion = num_descripcion;
        this.categoria = categoria;
        this.participante = participante;
        this.monto = monto;
    }

    public int getNum_descripcion() {
        return num_descripcion;
    }

    public void setNum_descripcion(int num_descripcion) {
        this.num_descripcion = num_descripcion;
    }

    public Categoria getCategoria() {
        return categoria;
    }

    public void setCategoria(Categoria categoria) {
        this.categoria = categoria;
    }

    public Participante getParticipante() {
        return participante;
    }

    public void setParticipante(Participante participante) {
        this.participante = participante;
    }

    public int getMonto() {
        return monto;
    }

    public void setMonto(int monto) {
        this.monto = monto;
    }
}
