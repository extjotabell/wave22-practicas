package main;

public class Main {

    public static void main(String[] args){
        String[] ciudad =   {   "Londres",      "Madrid",               "New York",
                                "Buenos Aires", "Asuncion",             "Sao Paulo",
                                "Lima",         "Santiago de Chile",    "Lisboa",
                                "Tokio"
                            };
        int[][] temperatura =   {
                                    {-2,33},{-3,32},{-8,27},
                                    {4,37}, {6,42}, {5,43},
                                    {0,39}, {-7,26},{-1,31},
                                    {-10,35}
                                };
        int menor = 0;
        int posMenor = 0;
        int mayor = 0;
        int posMayor = 0;
        final int COL_0 = 0;
        final int COL_1 = 1;

        for(int fila = 0; fila < temperatura.length; fila++) {
            if(temperatura[fila][COL_0] < menor){
                menor = temperatura[fila][COL_0];
                posMenor = fila;
            }
        }
        for(int fila = 0; fila < temperatura.length; fila++) {
            if(temperatura[fila][COL_1] > mayor){
                mayor = temperatura[fila][COL_1];
                posMayor = fila;
            }
        }

        System.out.println("La temperatura menor la tuvo: "+ciudad[posMenor]+" con "+menor);
        System.out.println("La temperatura mayor la tuvo: "+ciudad[posMayor]+" con "+mayor);
    }
}
